import React from "react";

export default function FinalizeCSL1() {
  return (
    <div className="flex flex-col items-center justify-center">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg ">
        <h1 className="text-xl p-4 font-semibold rounded-lg bg-purple-50 text-gray-700 mb-6">Finalize CS L1</h1>
        <form className="space-y-6 p-6">
          {/* Item 1 */}
          <div className="flex justify-between items-center">
            <label className="text-gray-800 font-medium">Copper Wire 10mm</label>
            <select className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 focus:outline-none focus:ring focus:ring-blue-300 w-60">
              <option>Select Vendor</option>
              <option>Vendor 1</option>
              <option>Vendor 2</option>
              <option>Vendor 3</option>
            </select>
          </div>

          {/* Item 2 */}
          <div className="flex justify-between items-center">
            <label className="text-gray-800 font-medium">Item 2</label>
            <select className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 focus:outline-none focus:ring focus:ring-blue-300 w-60">
              <option>Select Vendor</option>
              <option>Vendor 1</option>
              <option>Vendor 2</option>
              <option>Vendor 3</option>
            </select>
          </div>

          {/* Item 3 */}
          <div className="flex justify-between items-center">
            <label className="text-gray-800 font-medium">Item 3</label>
            <input
              type="text"
              value="SRH Engineers"
              readOnly
              className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 bg-gray-100 w-48 focus:outline-none w-60"
            />
          </div>

          {/* Buttons */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              className="px-4 py-2 bg-gray-100 text-gray-600 rounded-md border border-gray-300 hover:bg-gray-200 focus:outline-none"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
