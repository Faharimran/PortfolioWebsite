import React from "react";

export default function FinalizeCSL3() {
  return (
    <div className="flex flex-col items-center justify-center ">
      <div className="w-full max-w-5xl bg-white rounded-lg shadow-lg ">
        <h1 className="text-xl font-semibold rounded-lg bg-purple-50 text-gray-700 mb-6 p-4">Finalize CS L3</h1>
        <form className="space-y-6 p-6">
          {/* Item 1 */}
          <div className="grid grid-cols-4 gap-4 items-center">
            <label className="text-gray-800 font-medium">Copper Wire 10mm</label>
            <input
              type="text"
              value="Modern Marketing"
              readOnly
              className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 bg-gray-100"
            />
            <input
              type="text"
              value="Modern Marketing"
              readOnly
              className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 bg-gray-100"
            />
            <select className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 focus:outline-none focus:ring focus:ring-blue-300">
              <option>Select Vendor</option>
              <option>Vendor 1</option>
              <option>Vendor 2</option>
              <option>Vendor 3</option>
            </select>
          </div>

          {/* Item 2 */}
          <div className="grid grid-cols-4 gap-4 items-center">
            <label className="text-gray-800 font-medium">Item 2</label>
            <input
              type="text"
              value="Modern Marketing"
              readOnly
              className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 bg-gray-100"
            />
            <input
              type="text"
              value="Modern Marketing"
              readOnly
              className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 bg-gray-100"
            />
            <select className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 focus:outline-none focus:ring focus:ring-blue-300">
              <option>Select Vendor</option>
              <option>Vendor 1</option>
              <option>Vendor 2</option>
              <option>Vendor 3</option>
            </select>
          </div>

          {/* Item 3 */}
          <div className="grid grid-cols-4 gap-4 items-center">
            <label className="text-gray-800 font-medium">Item 3</label>
            <input
              type="text"
              value="SRH Engineers"
              readOnly
              className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 bg-gray-100"
            />
            <input
              type="text"
              value="SRH Engineers"
              readOnly
              className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 bg-gray-100"
            />
            <select className="border border-gray-300 rounded-md px-4 py-2 text-gray-600 focus:outline-none focus:ring focus:ring-blue-300">
              <option>Select Vendor</option>
              <option>Vendor 1</option>
              <option>Vendor 2</option>
              <option>Vendor 3</option>
            </select>
          </div>

          {/* Buttons */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              className="px-4 py-2 bg-gray-100 text-gray-600 rounded-md border border-gray-300 hover:bg-gray-200 focus:outline-none"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
